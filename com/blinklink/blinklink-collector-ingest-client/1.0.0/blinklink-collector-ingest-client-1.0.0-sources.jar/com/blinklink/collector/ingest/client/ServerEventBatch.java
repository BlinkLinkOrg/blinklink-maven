package com.blinklink.collector.ingest.client;

import java.time.Instant;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

/**
 * The generic builder for any server-known event type the contract allows (contract §11/§18.4) — the second,
 * typeless path alongside {@link ComposePageServed}. Use a namespace of your own, never {@code page}, {@code ui}
 * or {@code signal} ({@link EventType#ofServerType(String)}). Example:
 *
 * <pre>{@code
 * IngestBatch batch = ServerEventBatch.to(ServiceSource.of("blinklink-web-training"))
 *         .workspace(workspaceId).view(viewId)
 *         .consent(Consent.analyticsAndPersonal()).anon(Anon.of(partyId, sessionId))
 *         .event(EventType.ofServerType("training.lesson.completed"))
 *             .module(ModuleKey.of("training"))
 *             .ref(Ref.of("lesson", lessonId))
 *             .prop("score", 90)
 *             .add()
 *         .build();
 * }</pre>
 */
public final class ServerEventBatch {

    private final ServiceSource source;
    private WorkspaceId workspace;
    private ViewId view;
    private Instant sentAt;
    private Consent consent;
    private Anon anon = Anon.none();
    private ClientInfo client = ClientInfo.LIBRARY;
    private final List<ServerEvent> events = new ArrayList<>();

    private ServerEventBatch(ServiceSource source) {
        if (source == null) {
            throw new IngestValidationException("a source is required");
        }
        this.source = source;
    }

    public static ServerEventBatch to(ServiceSource source) {
        return new ServerEventBatch(source);
    }

    public ServerEventBatch workspace(WorkspaceId workspace) {
        this.workspace = workspace;
        return this;
    }

    public ServerEventBatch view(ViewId view) {
        this.view = view;
        return this;
    }

    public ServerEventBatch sentAt(Instant sentAt) {
        this.sentAt = sentAt;
        return this;
    }

    public ServerEventBatch consent(Consent consent) {
        this.consent = consent;
        return this;
    }

    public ServerEventBatch anon(Anon anon) {
        this.anon = anon == null ? Anon.none() : anon;
        return this;
    }

    public ServerEventBatch client(ClientInfo client) {
        this.client = client;
        return this;
    }

    /** Add an already-built event. */
    public ServerEventBatch add(ServerEvent event) {
        if (event == null) {
            throw new IngestValidationException("event must not be null");
        }
        events.add(event);
        return this;
    }

    /** Start one event of {@code type}; set it up, then {@link Event#add()} to attach it and return here. */
    public Event event(EventType type) {
        return new Event(this, type);
    }

    /** Validate and assemble the batch. */
    public IngestBatch build() {
        return new IngestBatch(workspace, source, view, sentAt, Optional.ofNullable(consent), anon,
                Optional.ofNullable(client), events);
    }

    /** A fluent spec for one event; {@link #add()} attaches it to the batch and returns the batch builder. */
    public static final class Event {

        private final ServerEventBatch parent;
        private final EventType type;
        private EventId eventId = EventId.of(UUID.randomUUID());
        private ModuleKey module;
        private int schema = 1;
        private Instant at = Instant.now();
        private double tMs;
        private long seq;
        private final List<Ref> refs = new ArrayList<>();
        private final Map<String, Object> props = new LinkedHashMap<>();

        private Event(ServerEventBatch parent, EventType type) {
            this.parent = parent;
            this.type = type;
        }

        public Event eventId(EventId eventId) {
            this.eventId = eventId == null ? this.eventId : eventId;
            return this;
        }

        public Event module(ModuleKey module) {
            this.module = module;
            return this;
        }

        public Event schema(int schema) {
            this.schema = schema;
            return this;
        }

        public Event at(Instant at) {
            this.at = at == null ? Instant.now() : at;
            return this;
        }

        public Event t(double tMs) {
            this.tMs = tMs;
            return this;
        }

        public Event seq(long seq) {
            this.seq = seq;
            return this;
        }

        public Event ref(Ref ref) {
            if (ref != null) {
                refs.add(ref);
            }
            return this;
        }

        public Event prop(String key, Object value) {
            props.put(key, value);
            return this;
        }

        public Event props(Map<String, Object> props) {
            if (props != null) {
                this.props.putAll(props);
            }
            return this;
        }

        /** Attach this event to the batch and return the batch builder. */
        public ServerEventBatch add() {
            parent.events.add(new ServerEvent(eventId, type, Optional.ofNullable(module), EventClass.INTERACTION,
                    schema, at, tMs, seq, refs, props));
            return parent;
        }
    }
}
