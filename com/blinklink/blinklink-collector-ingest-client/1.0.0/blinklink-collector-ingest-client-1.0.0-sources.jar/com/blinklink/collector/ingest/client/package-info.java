/**
 * Server-side ingest client for the v5 collector (collector-v5-design.md §0.13, §18) — the library compose
 * and embed <em>bake in</em> so firing a server-known event is one call, never a hand-rolled wire.
 *
 * <p>The browser SDK ({@code @blinklink/collect}) covers what the browser sees; this covers what only the
 * server knows — a page/fragment served, its {@code cache: HIT|MISS|BYPASS}, and {@code render_ms}
 * (contract §18.1 step 6, {@code compose.page.served}). A {@link ComposePageServed} (typed) or
 * {@link ServerEventBatch} (generic) builder validates against the collector's §6 grammar <em>client-side</em>
 * and serialises an {@link IngestBatch} into a transport-neutral {@code Message<byte[]>} — the JSON {@code Batch}
 * the collector parses, keyed by workspace id, with the {@code workspaceId} and {@code source} headers
 * (contract §11, asyncapi {@code ingestBatch}). No IP, User-Agent, cookie or token ever rides.
 *
 * <p>This core has no Kafka and no broker knowledge; the optional
 * {@link com.blinklink.collector.ingest.client.autoconfigure autoconfigure} package publishes the message
 * through the host app's Spring Cloud Stream {@code StreamBridge}.
 */
package com.blinklink.collector.ingest.client;
