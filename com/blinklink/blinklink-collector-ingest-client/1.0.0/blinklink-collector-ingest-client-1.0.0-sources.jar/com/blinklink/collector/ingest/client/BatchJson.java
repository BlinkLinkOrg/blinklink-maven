package com.blinklink.collector.ingest.client;

import tools.jackson.core.JacksonException;
import tools.jackson.databind.JsonNode;
import tools.jackson.databind.json.JsonMapper;
import tools.jackson.databind.node.ArrayNode;
import tools.jackson.databind.node.ObjectNode;

import java.nio.charset.StandardCharsets;

/**
 * Serialises an {@link IngestBatch} to the exact JSON {@code Batch} the collector's {@code BatchParser}/
 * {@code EventValidator} read (OpenAPI {@code Batch}/{@code Event}), and enforces the §6 {@code props} caps
 * ({@code ≤ 4096} bytes compact UTF-8, nesting {@code ≤ 5}) client-side. The only place wire JSON is written.
 */
final class BatchJson {

    /** §6 — compact-UTF-8 props cap (collector default {@code collector.limits.props-bytes}). */
    static final int MAX_PROPS_BYTES = 4096;
    /** §6 — props nesting cap ({@code props} object itself is depth 1). */
    static final int MAX_PROPS_DEPTH = 5;

    private static final JsonMapper JSON = JsonMapper.builder().build();

    private BatchJson() {
    }

    static byte[] toJson(IngestBatch batch) {
        ObjectNode root = JSON.createObjectNode();
        root.put("sentAt", batch.sentAt().toEpochMilli());
        root.put("view", batch.view().toString());
        batch.client().ifPresent(c -> {
            ObjectNode client = root.putObject("client");
            client.put("name", c.name());
            if (c.version() != null) {
                client.put("version", c.version());
            }
        });
        batch.consent().ifPresent(c -> {
            ObjectNode consent = root.putObject("consent");
            consent.put("analytics", c.analytics());
            consent.put("personal", c.personal());
            consent.put("biometrics", c.biometrics());
        });
        if (!batch.anon().isEmpty()) {
            ObjectNode anon = root.putObject("anon");
            batch.anon().party().ifPresent(p -> anon.put("party", p.toString()));
            batch.anon().session().ifPresent(s -> anon.put("session", s.toString()));
        }
        ArrayNode events = root.putArray("events");
        for (ServerEvent e : batch.events()) {
            events.add(event(e));
        }
        try {
            return JSON.writeValueAsBytes(root);
        } catch (JacksonException unserialisable) {
            throw new IngestValidationException("batch could not be serialised: " + unserialisable.getOriginalMessage());
        }
    }

    private static ObjectNode event(ServerEvent e) {
        ObjectNode node = JSON.createObjectNode();
        node.put("id", e.id().toString());
        node.put("type", e.type().toString());
        e.module().ifPresent(m -> node.put("module", m.toString()));
        node.put("schema", e.schema());
        node.put("at", e.at().toEpochMilli());
        node.put("t", e.tMs());
        node.put("seq", e.seq());
        if (!e.refs().isEmpty()) {
            ArrayNode refs = node.putArray("refs");
            e.refs().forEach(r -> refs.add(r.toString()));
        }
        if (!e.props().isEmpty()) {
            node.set("props", props(e.props()));
        }
        return node;
    }

    /** Convert, then size- and depth-check the props exactly as the collector does (§6), failing fast. */
    private static JsonNode props(java.util.Map<String, Object> props) {
        JsonNode node;
        try {
            node = JSON.valueToTree(props);
        } catch (RuntimeException notJson) {
            throw new IngestValidationException("props are not JSON-serialisable: " + notJson.getMessage());
        }
        if (!node.isObject()) {
            throw new IngestValidationException("props must be a JSON object");
        }
        int depth = depth(node);
        if (depth > MAX_PROPS_DEPTH) {
            throw new IngestValidationException("props nest deeper than " + MAX_PROPS_DEPTH + ": " + depth);
        }
        int bytes;
        try {
            bytes = JSON.writeValueAsString(node).getBytes(StandardCharsets.UTF_8).length;
        } catch (JacksonException unserialisable) {
            throw new IngestValidationException("props could not be serialised");
        }
        if (bytes > MAX_PROPS_BYTES) {
            throw new IngestValidationException("props over " + MAX_PROPS_BYTES + " bytes: " + bytes);
        }
        return node;
    }

    /** The props object is depth 1; each nested container adds one (mirrors the collector's EventValidator). */
    private static int depth(JsonNode node) {
        int max = 0;
        for (JsonNode child : node.values()) {
            if (child.isContainer()) {
                max = Math.max(max, depth(child));
            }
        }
        return 1 + max;
    }
}
