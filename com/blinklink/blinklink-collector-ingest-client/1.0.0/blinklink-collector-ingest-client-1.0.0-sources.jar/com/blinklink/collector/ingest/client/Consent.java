package com.blinklink.collector.ingest.client;

import org.jmolecules.ddd.annotation.ValueObject;

/**
 * The grant the events were collected under (contract §5/§6 {@code consent}). Without {@code analytics} the
 * collector withholds the whole batch; without {@code personal} it drops the party (so a sender should carry
 * the party only with {@code personal}, contract §6). {@code biometrics} gates signals.
 */
@ValueObject
public record Consent(boolean analytics, boolean personal, boolean biometrics) {

    public static Consent of(boolean analytics, boolean personal, boolean biometrics) {
        return new Consent(analytics, personal, biometrics);
    }

    /** Analytics + personal granted, biometrics not — the common signed-in-with-consent case. */
    public static Consent analyticsAndPersonal() {
        return new Consent(true, true, false);
    }

    /** Analytics only — no personal data, so no party is carried. */
    public static Consent analyticsOnly() {
        return new Consent(true, false, false);
    }
}
