package com.blinklink.collector.ingest.client;

import org.springframework.messaging.Message;
import org.springframework.messaging.support.MessageBuilder;

import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.List;
import java.util.Optional;

/**
 * A ready-to-produce service-ingest batch — the JSON {@code Batch} plus the destination workspace and the
 * producing {@code source} (contract §11, asyncapi {@code ingestBatch}). {@link #toMessage()} renders it as a
 * transport-neutral {@code Message<byte[]>} (payload + the {@code workspaceId}/{@code source} headers + the
 * workspace-id key) that the host app publishes through Spring Cloud Stream. Build one with
 * {@link ComposePageServed} or {@link ServerEventBatch}; this type carries no IP, User-Agent, cookie or token.
 */
public record IngestBatch(
        WorkspaceId workspace,
        ServiceSource source,
        ViewId view,
        Instant sentAt,
        Optional<Consent> consent,
        Anon anon,
        Optional<ClientInfo> client,
        List<ServerEvent> events
) {

    /** §2 — a batch carries 1..100 events. */
    static final int MAX_EVENTS = 100;

    public IngestBatch {
        if (workspace == null) {
            throw new IngestValidationException("a batch needs a workspace id");
        }
        if (source == null) {
            throw new IngestValidationException("a batch needs a source");
        }
        if (view == null) {
            throw new IngestValidationException("a batch needs a view id (contract §2: view is required)");
        }
        sentAt = sentAt == null ? Instant.now() : sentAt;
        consent = consent == null ? Optional.empty() : consent;
        anon = anon == null ? Anon.none() : anon;
        client = client == null ? Optional.empty() : client;
        if (events == null || events.isEmpty() || events.size() > MAX_EVENTS) {
            throw new IngestValidationException("a batch carries 1.." + MAX_EVENTS + " events: "
                    + (events == null ? 0 : events.size()));
        }
        events = List.copyOf(events);
    }

    /** The JSON {@code Batch} body the collector parses. */
    public byte[] toJson() {
        return BatchJson.toJson(this);
    }

    /**
     * The batch as a {@code Message<byte[]>}: the JSON body, the {@code workspaceId} and {@code source} plain
     * Kafka headers, and the record key (= the workspace id) — the exact shape the collector's service-ingest
     * consumer accepts. Header and key values are {@code byte[]} (UTF-8), the collector's own convention.
     */
    public Message<byte[]> toMessage() {
        byte[] key = workspace.toString().getBytes(StandardCharsets.UTF_8);
        return MessageBuilder.withPayload(toJson())
                .setHeader(CollectorIngest.WORKSPACE_ID_HEADER, key)
                .setHeader(CollectorIngest.SOURCE_HEADER, source.toString().getBytes(StandardCharsets.UTF_8))
                .setHeader(CollectorIngest.MESSAGE_KEY_HEADER, key)
                .build();
    }
}
