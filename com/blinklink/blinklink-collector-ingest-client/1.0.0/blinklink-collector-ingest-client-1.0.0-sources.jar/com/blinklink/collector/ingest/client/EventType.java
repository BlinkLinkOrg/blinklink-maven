package com.blinklink.collector.ingest.client;

import org.jmolecules.ddd.annotation.ValueObject;

import java.util.Set;
import java.util.regex.Pattern;

/**
 * An event's {@code type}: {@code <namespace>.<object>.<action>}, lower-case, ≤ 64 characters (contract §6).
 * A server-side sender uses a namespace of its own, never the shared browser-capture namespaces {@code page},
 * {@code ui} or {@code signal} (contract §18.4) — {@link #ofServerType(String)} enforces that.
 */
@ValueObject
public record EventType(String value) {

    static final int MAX_LENGTH = 64;
    private static final Pattern SHAPE = Pattern.compile("^[a-z][a-z0-9]*(\\.[a-z][a-z0-9_]*){2}$");
    /** Shared namespaces reserved for browser capture — a server sender must not use them (contract §18.4). */
    private static final Set<String> RESERVED_NAMESPACES = Set.of("page", "ui", "signal");

    public EventType {
        if (value == null || value.length() > MAX_LENGTH || !SHAPE.matcher(value).matches()) {
            throw new IngestValidationException("not an event type (<namespace>.<object>.<action>): " + value);
        }
    }

    /** Any valid type. */
    public static EventType of(String raw) {
        return new EventType(raw);
    }

    /** A server-side type: valid, and not in a reserved browser-capture namespace (contract §18.4). */
    public static EventType ofServerType(String raw) {
        EventType type = new EventType(raw);
        if (RESERVED_NAMESPACES.contains(type.namespace())) {
            throw new IngestValidationException(
                    "a server event must use its own namespace, never page/ui/signal (contract §18.4): " + raw);
        }
        return type;
    }

    public String namespace() {
        return value.substring(0, value.indexOf('.'));
    }

    @Override
    public String toString() {
        return value;
    }
}
