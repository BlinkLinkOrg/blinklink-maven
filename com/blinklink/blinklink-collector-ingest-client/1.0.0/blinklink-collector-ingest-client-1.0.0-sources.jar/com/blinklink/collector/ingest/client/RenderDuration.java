package com.blinklink.collector.ingest.client;

import org.jmolecules.ddd.annotation.ValueObject;

import java.time.Duration;

/**
 * How long the server took to render a page/fragment — the {@code render_ms} prop of
 * {@code compose.page.served} (contract §18.1 step 6). Non-negative; serialised as whole milliseconds.
 */
@ValueObject
public record RenderDuration(long millis) {

    public RenderDuration {
        if (millis < 0) {
            throw new IngestValidationException("render duration must be ≥ 0 ms: " + millis);
        }
    }

    public static RenderDuration ofMillis(long millis) {
        return new RenderDuration(millis);
    }

    public static RenderDuration of(Duration duration) {
        return new RenderDuration(duration.toMillis());
    }
}
