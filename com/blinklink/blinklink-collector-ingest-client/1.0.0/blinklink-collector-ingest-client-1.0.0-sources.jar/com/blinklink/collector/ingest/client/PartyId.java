package com.blinklink.collector.ingest.client;

import org.jmolecules.ddd.annotation.ValueObject;
import org.jmolecules.ddd.types.Identifier;

import java.util.UUID;

/** Typed id (value object) — a bare {@link UUID}/{@link String} never stands for it (partner-v5 rule 2). */
@ValueObject
public record PartyId(UUID value) implements Identifier {

    public PartyId {
        if (value == null) {
            throw new IllegalArgumentException("PartyId value must not be null");
        }
    }

    /** From an already-typed {@link UUID}. */
    public static PartyId of(UUID value) {
        return new PartyId(value);
    }

    /** From its canonical text; a typed {@link IngestValidationException} when it is not a UUID. */
    public static PartyId of(String raw) {
        try {
            return new PartyId(UUID.fromString(raw));
        } catch (RuntimeException notAUuid) {
            throw new IngestValidationException("PartyId must be a UUID: " + raw);
        }
    }

    /** Lower-case canonical text — the form on the wire and in the Kafka key. */
    @Override
    public String toString() {
        return value.toString();
    }
}
