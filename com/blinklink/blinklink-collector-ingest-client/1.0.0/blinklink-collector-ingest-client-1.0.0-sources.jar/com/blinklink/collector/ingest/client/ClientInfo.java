package com.blinklink.collector.ingest.client;

import org.jmolecules.ddd.annotation.ValueObject;

/** The sending client's {@code name} + {@code version} (contract {@code Batch.client}); stamped on each event. */
@ValueObject
public record ClientInfo(String name, String version) {

    /** This library, as it identifies itself on the wire by default. */
    public static final ClientInfo LIBRARY = new ClientInfo("blinklink-collector-ingest-client", "1.0.0");

    public ClientInfo {
        if (name == null || name.isBlank()) {
            throw new IngestValidationException("client name must not be blank");
        }
    }
}
