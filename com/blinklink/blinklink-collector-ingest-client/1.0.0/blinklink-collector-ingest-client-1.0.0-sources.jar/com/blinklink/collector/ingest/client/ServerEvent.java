package com.blinklink.collector.ingest.client;

import org.jmolecules.ddd.annotation.ValueObject;

import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * One server-known observation, validated against the collector's §6 grammar on construction (so a bad event
 * is refused here, not over the wire). {@code props} is free JSON owned by the type; it is size/depth checked
 * when the batch is serialised. Build one through {@link ComposePageServed} or {@link ServerEventBatch}.
 */
@ValueObject
public record ServerEvent(
        EventId id,
        EventType type,
        Optional<ModuleKey> module,
        EventClass eventClass,
        int schema,
        Instant at,
        double tMs,
        long seq,
        List<Ref> refs,
        Map<String, Object> props
) {

    static final int MAX_REFS = 20;
    static final int MIN_SCHEMA = 1;
    static final int MAX_SCHEMA = 1000;

    public ServerEvent {
        if (id == null || type == null || at == null) {
            throw new IngestValidationException("a server event needs an id, a type and an at");
        }
        module = module == null ? Optional.empty() : module;
        eventClass = eventClass == null ? EventClass.INTERACTION : eventClass;
        if (eventClass == EventClass.SIGNAL) {
            throw new IngestValidationException("a server event is an interaction, never a signal (contract §6)");
        }
        if (schema < MIN_SCHEMA || schema > MAX_SCHEMA) {
            throw new IngestValidationException("schema must be 1..1000: " + schema);
        }
        if (tMs < 0 || !Double.isFinite(tMs)) {
            throw new IngestValidationException("t must be a finite number ≥ 0: " + tMs);
        }
        if (seq < 0) {
            throw new IngestValidationException("seq must be ≥ 0: " + seq);
        }
        refs = refs == null ? List.of() : List.copyOf(refs);
        if (refs.size() > MAX_REFS) {
            throw new IngestValidationException("at most " + MAX_REFS + " refs: " + refs.size());
        }
        props = props == null ? Map.of() : Map.copyOf(props);
    }
}
