package com.blinklink.collector.ingest.client;

import java.time.Instant;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

/**
 * The typed builder for {@code compose.page.served} (contract §18.1 step 6): one event per document navigation
 * carrying {@code props} {@code {cache: HIT|MISS|BYPASS per fragment, render_ms}}, the party/session the server
 * resolved, and the request's consent. Example:
 *
 * <pre>{@code
 * IngestBatch batch = ComposePageServed.to(ServiceSource.COMPOSE)
 *         .workspace(workspaceId).view(viewId)
 *         .fragment("shell", CacheOutcome.HIT)
 *         .fragment("body",  CacheOutcome.MISS)
 *         .renderDuration(RenderDuration.ofMillis(42))
 *         .anon(Anon.of(partyId, sessionId))          // party only with the personal grant (§6)
 *         .consent(Consent.analyticsAndPersonal())
 *         .build();
 * }</pre>
 */
public final class ComposePageServed {

    private static final EventType TYPE = EventType.of("compose.page.served");

    private final ServiceSource source;
    private WorkspaceId workspace;
    private ViewId view;
    private EventId eventId = EventId.of(UUID.randomUUID());
    private ModuleKey module = ModuleKey.COMPOSE;
    private Instant at = Instant.now();
    private Instant sentAt;
    private double tMs;
    private long seq;
    private final LinkedHashMap<String, CacheOutcome> fragments = new LinkedHashMap<>();
    private RenderDuration render;
    private Consent consent;
    private Anon anon = Anon.none();
    private ClientInfo client = ClientInfo.LIBRARY;
    private final List<Ref> refs = new ArrayList<>();

    private ComposePageServed(ServiceSource source) {
        if (source == null) {
            throw new IngestValidationException("a source is required");
        }
        this.source = source;
    }

    /** Start a {@code compose.page.served} from the producing service's name (e.g. {@link ServiceSource#COMPOSE}). */
    public static ComposePageServed to(ServiceSource source) {
        return new ComposePageServed(source);
    }

    public ComposePageServed workspace(WorkspaceId workspace) {
        this.workspace = workspace;
        return this;
    }

    public ComposePageServed view(ViewId view) {
        this.view = view;
        return this;
    }

    /** Record one fragment's cache result; call once per fragment of the navigation. */
    public ComposePageServed fragment(String name, CacheOutcome outcome) {
        if (name == null || name.isBlank()) {
            throw new IngestValidationException("a fragment name must not be blank");
        }
        if (outcome == null) {
            throw new IngestValidationException("a cache outcome is required for fragment " + name);
        }
        fragments.put(name, outcome);
        return this;
    }

    public ComposePageServed renderDuration(RenderDuration render) {
        this.render = render;
        return this;
    }

    public ComposePageServed anon(Anon anon) {
        this.anon = anon == null ? Anon.none() : anon;
        return this;
    }

    /** The party and session the server resolved — carry the party only with the {@code personal} grant (§6). */
    public ComposePageServed identified(PartyId party, SessionId session) {
        return anon(Anon.of(party, session));
    }

    public ComposePageServed consent(Consent consent) {
        this.consent = consent;
        return this;
    }

    public ComposePageServed ref(Ref ref) {
        if (ref != null) {
            refs.add(ref);
        }
        return this;
    }

    public ComposePageServed module(ModuleKey module) {
        this.module = module == null ? ModuleKey.COMPOSE : module;
        return this;
    }

    public ComposePageServed eventId(EventId eventId) {
        this.eventId = eventId == null ? this.eventId : eventId;
        return this;
    }

    /** The event's wall-clock time (and, unless {@link #sentAt(Instant)} is set, the batch send time). */
    public ComposePageServed at(Instant at) {
        this.at = at == null ? Instant.now() : at;
        return this;
    }

    public ComposePageServed sentAt(Instant sentAt) {
        this.sentAt = sentAt;
        return this;
    }

    public ComposePageServed t(double tMs) {
        this.tMs = tMs;
        return this;
    }

    public ComposePageServed seq(long seq) {
        this.seq = seq;
        return this;
    }

    public ComposePageServed client(ClientInfo client) {
        this.client = client;
        return this;
    }

    /** Validate and assemble the batch; a {@link IngestValidationException} on anything the collector would refuse. */
    public IngestBatch build() {
        if (render == null) {
            throw new IngestValidationException("compose.page.served needs a render duration (render_ms)");
        }
        Map<String, Object> props = new LinkedHashMap<>();
        if (!fragments.isEmpty()) {
            LinkedHashMap<String, String> cache = new LinkedHashMap<>();
            fragments.forEach((name, outcome) -> cache.put(name, outcome.wire()));
            props.put("cache", cache);
        }
        props.put("render_ms", render.millis());
        ServerEvent event = new ServerEvent(eventId, TYPE, Optional.of(module), EventClass.INTERACTION, 1,
                at, tMs, seq, refs, props);
        return new IngestBatch(workspace, source, view, sentAt == null ? at : sentAt,
                Optional.ofNullable(consent), anon, Optional.ofNullable(client), List.of(event));
    }
}
