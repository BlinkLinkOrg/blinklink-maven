package com.blinklink.collector.ingest.client;

import java.util.Optional;

/**
 * The anonymous ids a service asserts (contract {@code Batch.anon}) — the party and session <em>it</em> resolved
 * for the request. A trusted source's are stamped {@code TICKET} (contract §11). Carry the party only with the
 * {@code personal} grant (contract §6): {@link #sessionOnly(SessionId)} is the no-party form.
 */
public record Anon(Optional<PartyId> party, Optional<SessionId> session) {

    public Anon {
        party = party == null ? Optional.empty() : party;
        session = session == null ? Optional.empty() : session;
    }

    public static Anon none() {
        return new Anon(Optional.empty(), Optional.empty());
    }

    public static Anon of(PartyId party, SessionId session) {
        return new Anon(Optional.ofNullable(party), Optional.ofNullable(session));
    }

    public static Anon sessionOnly(SessionId session) {
        return new Anon(Optional.empty(), Optional.ofNullable(session));
    }

    boolean isEmpty() {
        return party.isEmpty() && session.isEmpty();
    }
}
