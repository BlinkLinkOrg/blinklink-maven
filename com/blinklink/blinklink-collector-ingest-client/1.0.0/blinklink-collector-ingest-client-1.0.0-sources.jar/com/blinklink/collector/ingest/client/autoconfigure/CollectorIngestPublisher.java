package com.blinklink.collector.ingest.client.autoconfigure;

import com.blinklink.collector.ingest.client.IngestBatch;
import org.springframework.cloud.stream.function.StreamBridge;
import org.springframework.messaging.Message;

/**
 * Publishes a service-ingest batch to {@code blinklink.collector.ingest.v1} through the host's {@code StreamBridge}
 * (contract §11). Transport is the host binder's concern; this only renders the batch to its {@code Message<byte[]>}
 * and sends it to the configured binding. {@link #publish(IngestBatch)} returns whether the binder accepted it —
 * a caller wanting fire-and-forget (never blocking or failing a render, contract §18.1) runs it on its own
 * bounded executor and records failures itself.
 */
public class CollectorIngestPublisher {

    private final StreamBridge streamBridge;
    private final String binding;

    public CollectorIngestPublisher(StreamBridge streamBridge, String binding) {
        this.streamBridge = streamBridge;
        this.binding = binding;
    }

    /** Send the batch; {@code true} when the binder accepted it for delivery. */
    public boolean publish(IngestBatch batch) {
        return publish(batch.toMessage());
    }

    /** Send an already-rendered message (e.g. one built by the core and inspected in a test). */
    public boolean publish(Message<byte[]> message) {
        return streamBridge.send(binding, message);
    }

    /** The output binding this publisher sends to. */
    public String binding() {
        return binding;
    }
}
