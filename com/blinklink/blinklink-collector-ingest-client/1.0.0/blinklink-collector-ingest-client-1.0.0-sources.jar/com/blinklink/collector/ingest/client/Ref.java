package com.blinklink.collector.ingest.client;

import org.jmolecules.ddd.annotation.ValueObject;

import java.util.regex.Pattern;

/** What an event is about, as a {@code noun:id} tag ≤ 128 characters (contract §6 {@code refs}); first = subject. */
@ValueObject
public record Ref(String value) {

    static final int MAX_LENGTH = 128;
    private static final Pattern SHAPE = Pattern.compile("^[a-z][a-z_]*:[^\\s]+$");

    public Ref {
        if (value == null || value.length() > MAX_LENGTH || !SHAPE.matcher(value).matches()) {
            throw new IngestValidationException("not a noun:id ref (≤128 chars): " + value);
        }
    }

    public static Ref of(String raw) {
        return new Ref(raw);
    }

    /** A {@code noun:id} ref from its two halves. */
    public static Ref of(String noun, String id) {
        return new Ref(noun + ":" + id);
    }

    @Override
    public String toString() {
        return value;
    }
}
