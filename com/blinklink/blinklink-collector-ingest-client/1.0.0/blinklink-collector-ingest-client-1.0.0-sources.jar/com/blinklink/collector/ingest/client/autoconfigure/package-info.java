/**
 * Optional Spring Boot auto-configuration that publishes an {@link com.blinklink.collector.ingest.client.IngestBatch}
 * through the host app's Spring Cloud Stream {@code StreamBridge} (the platform rule — never raw Spring Kafka).
 * It contributes no binder and knows no broker address: the host app's binder configuration supplies them
 * (infra-unaware). Switch off with {@code collector.ingest.client.enabled=false}; point it at a binding with
 * {@code collector.ingest.client.binding} (default {@code collectorIngest-out-0}).
 */
package com.blinklink.collector.ingest.client.autoconfigure;
