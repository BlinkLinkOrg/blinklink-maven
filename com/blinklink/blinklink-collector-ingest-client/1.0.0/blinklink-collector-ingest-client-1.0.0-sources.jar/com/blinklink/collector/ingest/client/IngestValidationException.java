package com.blinklink.collector.ingest.client;

/**
 * A client-side refusal: the event or batch would break the collector's §6 grammar / size rules, so the
 * builder fails fast here rather than letting the collector refuse it over the wire. Unchecked — a server
 * event that violates the contract is a programming error in the caller.
 */
public class IngestValidationException extends RuntimeException {

    public IngestValidationException(String message) {
        super(message);
    }
}
