package com.blinklink.collector.ingest.client.autoconfigure;

import com.blinklink.collector.ingest.client.ServiceSource;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.cloud.stream.function.StreamBridge;
import org.springframework.context.annotation.Bean;

/**
 * Wires the {@link CollectorIngestPublisher} when the host app has Spring Cloud Stream on the classpath and has
 * not switched the client off ({@code collector.ingest.client.enabled=false}). It adds no binder and no broker
 * config; the host's binder does that.
 */
@AutoConfiguration
@ConditionalOnClass(StreamBridge.class)
@ConditionalOnProperty(prefix = "collector.ingest.client", name = "enabled", havingValue = "true", matchIfMissing = true)
@EnableConfigurationProperties(CollectorIngestProperties.class)
public class CollectorIngestAutoConfiguration {

    @Bean
    @ConditionalOnMissingBean
    CollectorIngestPublisher collectorIngestPublisher(StreamBridge streamBridge, CollectorIngestProperties properties) {
        return new CollectorIngestPublisher(streamBridge, properties.binding());
    }

    /** The configured producing source, for callers that build batches with {@code ServerEventBatch.to(source)}. */
    @Bean
    @ConditionalOnMissingBean
    ServiceSource collectorIngestSource(CollectorIngestProperties properties) {
        return ServiceSource.of(properties.source());
    }
}
