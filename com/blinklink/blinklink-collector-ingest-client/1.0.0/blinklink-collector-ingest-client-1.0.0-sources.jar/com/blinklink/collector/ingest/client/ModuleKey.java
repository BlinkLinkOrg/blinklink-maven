package com.blinklink.collector.ingest.client;

import org.jmolecules.ddd.annotation.ValueObject;

import java.util.regex.Pattern;

/** The sending module ({@code compose}, {@code engagement}, …) — contract §6 {@code module}. */
@ValueObject
public record ModuleKey(String value) {

    private static final Pattern SHAPE = Pattern.compile("^[a-z][a-z0-9-]{0,31}$");

    /** Compose's own module key — the default on a {@link ComposePageServed}. */
    public static final ModuleKey COMPOSE = new ModuleKey("compose");

    public ModuleKey {
        if (value == null || !SHAPE.matcher(value).matches()) {
            throw new IngestValidationException("not a module key: " + value);
        }
    }

    public static ModuleKey of(String raw) {
        return new ModuleKey(raw);
    }

    @Override
    public String toString() {
        return value;
    }
}
