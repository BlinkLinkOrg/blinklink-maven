package com.blinklink.collector.ingest.client;

import org.jmolecules.ddd.annotation.ValueObject;

/**
 * The producing service's name — the record's {@code source} (contract §11). When it is in the collector's
 * {@code collector.ingest.trusted-sources}, the service's {@code anon} party/session are stamped {@code TICKET}
 * (trusted, as compose's are); otherwise {@code ASSERTED}. A free-text name, validated for length only.
 */
@ValueObject
public record ServiceSource(String value) {

    static final int MAX_LENGTH = 128;

    /** Compose's source name — the default trusted source in {@code collector.ingest.trusted-sources}. */
    public static final ServiceSource COMPOSE = new ServiceSource("blinklink-web-compose");

    public ServiceSource {
        if (value == null || value.isBlank() || value.length() > MAX_LENGTH) {
            throw new IngestValidationException("not an ingest source (1..128 chars): " + value);
        }
    }

    public static ServiceSource of(String raw) {
        return new ServiceSource(raw == null ? null : raw.trim());
    }

    @Override
    public String toString() {
        return value;
    }
}
