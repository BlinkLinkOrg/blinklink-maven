package com.blinklink.collector.ingest.client.autoconfigure;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.bind.DefaultValue;

/**
 * Host configuration for the ingest publisher ({@code collector.ingest.client.*}). No broker address lives here
 * — the host app's Spring Cloud Stream binder supplies that; this only names the output binding and the
 * producing {@code source}.
 */
@ConfigurationProperties("collector.ingest.client")
public record CollectorIngestProperties(
        @DefaultValue("true") boolean enabled,
        @DefaultValue("collectorIngest-out-0") String binding,
        @DefaultValue("blinklink-web-compose") String source
) {
}
