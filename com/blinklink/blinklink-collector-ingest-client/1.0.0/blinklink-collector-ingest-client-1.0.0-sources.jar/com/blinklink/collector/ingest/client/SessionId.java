package com.blinklink.collector.ingest.client;

import org.jmolecules.ddd.annotation.ValueObject;
import org.jmolecules.ddd.types.Identifier;

import java.util.UUID;

/** Typed id (value object) — a bare {@link UUID}/{@link String} never stands for it (partner-v5 rule 2). */
@ValueObject
public record SessionId(UUID value) implements Identifier {

    public SessionId {
        if (value == null) {
            throw new IllegalArgumentException("SessionId value must not be null");
        }
    }

    /** From an already-typed {@link UUID}. */
    public static SessionId of(UUID value) {
        return new SessionId(value);
    }

    /** From its canonical text; a typed {@link IngestValidationException} when it is not a UUID. */
    public static SessionId of(String raw) {
        try {
            return new SessionId(UUID.fromString(raw));
        } catch (RuntimeException notAUuid) {
            throw new IngestValidationException("SessionId must be a UUID: " + raw);
        }
    }

    /** Lower-case canonical text — the form on the wire and in the Kafka key. */
    @Override
    public String toString() {
        return value.toString();
    }
}
