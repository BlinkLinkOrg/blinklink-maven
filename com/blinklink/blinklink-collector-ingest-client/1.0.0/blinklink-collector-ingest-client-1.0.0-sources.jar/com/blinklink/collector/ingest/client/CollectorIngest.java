package com.blinklink.collector.ingest.client;

/**
 * The one place the service-ingest wire names live (contract §11, asyncapi {@code ingest} channel) — the topic
 * and the plain Kafka header names a record carries, so no name is ever a scattered magic string. These mirror
 * the collector's {@code com.blinklink.collector.produce.Topics.SERVICE_INGEST} and
 * {@code com.blinklink.collector.produce.EventHeaders}; a contract test asserts they stay identical.
 */
public final class CollectorIngest {

    /** The topic services produce their JSON {@code Batch} to (asyncapi {@code blinklink.collector.ingest.v1}). */
    public static final String TOPIC = "blinklink.collector.ingest.v1";

    /** Header: the destination workspace id (required). The collector takes the tenant from it (contract §11). */
    public static final String WORKSPACE_ID_HEADER = "workspaceId";

    /** Header: the producing service's name; trusted (ids stamped {@code TICKET}) when in the collector's
     *  {@code collector.ingest.trusted-sources}, else {@code ASSERTED} (contract §11). */
    public static final String SOURCE_HEADER = "source";

    /** Header carrying the record key (= the value of Spring Kafka's {@code KafkaHeaders.KEY}); kept as a
     *  literal so the core needs no Kafka dependency. The Kafka binder reads it as the partition key. */
    public static final String MESSAGE_KEY_HEADER = "kafka_messageKey";

    private CollectorIngest() {
    }
}
