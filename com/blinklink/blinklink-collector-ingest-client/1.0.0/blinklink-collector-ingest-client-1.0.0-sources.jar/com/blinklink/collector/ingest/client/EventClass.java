package com.blinklink.collector.ingest.client;

/**
 * An event's class (contract §6): {@code interaction} (the default) or {@code signal} (the biometrics grant,
 * only in the {@code signal} namespace). Each carries its wire spelling once. A server delivery event such as
 * {@code compose.page.served} is {@code INTERACTION}.
 */
public enum EventClass {
    INTERACTION("interaction"),
    SIGNAL("signal");

    private final String wire;

    EventClass(String wire) {
        this.wire = wire;
    }

    public String wire() {
        return wire;
    }
}
