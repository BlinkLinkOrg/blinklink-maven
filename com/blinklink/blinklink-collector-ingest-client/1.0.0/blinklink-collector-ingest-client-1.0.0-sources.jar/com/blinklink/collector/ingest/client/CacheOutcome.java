package com.blinklink.collector.ingest.client;

/**
 * A fragment's cache result on the Compose Serving Path — the per-fragment {@code cache} value of
 * {@code compose.page.served} (contract §18.1 step 6). Each carries its wire spelling once; no string magic.
 */
public enum CacheOutcome {
    HIT("HIT"),
    MISS("MISS"),
    BYPASS("BYPASS");

    private final String wire;

    CacheOutcome(String wire) {
        this.wire = wire;
    }

    /** The value written on the wire ({@code HIT} / {@code MISS} / {@code BYPASS}). */
    public String wire() {
        return wire;
    }
}
