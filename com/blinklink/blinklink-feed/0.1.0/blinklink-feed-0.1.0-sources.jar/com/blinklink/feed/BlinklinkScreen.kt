package com.blinklink.feed

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.blinklink.feed.internal.PlaceholderCard

/**
 * A server-driven Blinklink screen (e.g. `"inspire"` — the full Frontline
 * Feed experience with search, filters, banner, and video grid).
 *
 * ```
 * BlinklinkScreen(screenId = "inspire")
 * ```
 */
@Composable
fun BlinklinkScreen(
    screenId: String = "inspire",
    modifier: Modifier = Modifier,
) {
    PlaceholderCard(
        surface = "Screen · $screenId",
        modifier = modifier,
    )
}
