package com.blinklink.feed

/** Layout of a referrer feed embed. */
enum class FeedLayout {
    Carousel,
    Carousel3D,
    Grid,
}
