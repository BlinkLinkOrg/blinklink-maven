package com.blinklink.feed

import android.content.Context
import android.util.Log
import androidx.fragment.app.Fragment

/**
 * The Blinklink Feed SDK entry point.
 *
 * ```
 * Blinklink.initialize(this, clientId = "YOUR_CLIENT_ID")
 * ```
 *
 * NOTE (0.x): this release is an API-stable shell — the full 1.0 API
 * compiles and runs, and every surface renders a Blinklink placeholder.
 * The native Android renderer arrives in an upcoming release with no
 * integration changes.
 */
object Blinklink {

    internal data class Runtime(
        val clientId: String,
        val environment: BlinklinkEnvironment,
        val stream: String,
        val placement: String,
    )

    internal var runtime: Runtime? = null
        private set

    internal var userRef: String? = null
        private set

    /**
     * Configure the SDK once at app startup (e.g. in [android.app.Application.onCreate]).
     *
     * @param context any context; only used for future renderer initialization.
     * @param clientId your Client ID from the Blinklink portal.
     * @param environment backend environment (default [BlinklinkEnvironment.PRODUCTION]).
     * @param stream the stream identifier provisioned for your account.
     * @param placement the placement identifier provisioned for your account.
     */
    @JvmStatic
    @JvmOverloads
    fun initialize(
        context: Context,
        clientId: String,
        environment: BlinklinkEnvironment = BlinklinkEnvironment.PRODUCTION,
        stream: String = "videos",
        placement: String = "videos-tab",
    ) {
        runtime = Runtime(clientId, environment, stream, placement)
        Log.i(
            TAG,
            "initialized (clientId=${clientId.take(8)}…, env=$environment) — " +
                "Android renderer coming soon; surfaces render a placeholder in this release",
        )
    }

    /**
     * Associate your own user reference with this device so likes and
     * personalization follow the account across devices.
     */
    @JvmStatic
    fun setUser(ref: String) {
        userRef = ref
    }

    /** Clear the user association (logout). */
    @JvmStatic
    fun clearUser() {
        userRef = null
    }

    /**
     * A fragment rendering a server-driven screen — drop it into any
     * container. Compose apps use [BlinklinkScreen] instead.
     */
    @JvmStatic
    fun screenFragment(screenId: String): Fragment = BlinklinkScreenFragment.newInstance(screenId)

    internal const val TAG = "Blinklink"
}
