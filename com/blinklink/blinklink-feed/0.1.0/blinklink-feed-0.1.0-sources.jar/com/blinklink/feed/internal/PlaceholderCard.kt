package com.blinklink.feed.internal

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.blinklink.feed.Blinklink

/**
 * The 0.x shell placeholder: a branded card confirming the SDK is wired up
 * (shows the configured clientId prefix + environment) until the native
 * Android renderer ships.
 */
@Composable
internal fun PlaceholderCard(
    surface: String,
    modifier: Modifier = Modifier,
) {
    val runtime = Blinklink.runtime
    Surface(modifier = modifier.fillMaxSize(), color = Color(0xFF101014)) {
        Column(
            modifier = Modifier.padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterVertically),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(
                text = "Blinklink",
                color = Color.White,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
            )
            Text(
                text = "Android renderer coming soon",
                color = Color(0xFFB8B8C0),
                fontSize = 14.sp,
            )
            Text(
                text = surface,
                color = Color(0xFF8A8A94),
                fontSize = 12.sp,
            )
            val status = if (runtime != null) {
                "✓ initialized · ${runtime.clientId.take(8)}… · ${runtime.environment}"
            } else {
                "⚠ Blinklink.initialize(…) has not been called"
            }
            Text(
                text = status,
                color = if (runtime != null) Color(0xFF7ED9A0) else Color(0xFFE9B44C),
                fontSize = 12.sp,
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF1C1C22))
                    .padding(horizontal = 10.dp, vertical = 6.dp),
            )
        }
    }
}
