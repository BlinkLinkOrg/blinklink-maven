package com.blinklink.feed

import android.content.Context
import android.util.AttributeSet
import android.widget.FrameLayout
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.ComposeView
import com.blinklink.feed.internal.PlaceholderCard

/**
 * A referrer feed embed (Compose).
 *
 * ```
 * BlinklinkFeedView(stream = "videos", placement = "home-carousel", layout = FeedLayout.Carousel)
 * ```
 */
@Composable
fun BlinklinkFeedView(
    stream: String = "videos",
    placement: String = "videos-tab",
    layout: FeedLayout = FeedLayout.Carousel,
    title: String? = null,
    modifier: Modifier = Modifier,
) {
    PlaceholderCard(
        surface = "Feed · ${layout.name}" + (title?.let { " · $it" } ?: ""),
        modifier = modifier,
    )
}

/**
 * A referrer feed embed for View-based apps — add it to any layout.
 */
class BlinklinkFeedView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0,
) : FrameLayout(context, attrs, defStyleAttr) {

    var stream: String = "videos"
    var placement: String = "videos-tab"
    var layout: FeedLayout = FeedLayout.Carousel
    var title: String? = null

    init {
        addView(
            ComposeView(context).apply {
                setContent {
                    PlaceholderCard(surface = "Feed · ${layout.name}")
                }
            },
        )
    }
}
