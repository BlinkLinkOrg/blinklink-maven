package com.blinklink.feed

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.compose.ui.platform.ComposeView
import androidx.fragment.app.Fragment

/** Fragment form of [BlinklinkScreen] for View-based apps. */
class BlinklinkScreenFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        val screenId = arguments?.getString(ARG_SCREEN_ID) ?: "inspire"
        return ComposeView(requireContext()).apply {
            setContent {
                BlinklinkScreen(screenId = screenId)
            }
        }
    }

    companion object {
        private const val ARG_SCREEN_ID = "screen_id"

        fun newInstance(screenId: String): BlinklinkScreenFragment =
            BlinklinkScreenFragment().apply {
                arguments = Bundle().apply { putString(ARG_SCREEN_ID, screenId) }
            }
    }
}
