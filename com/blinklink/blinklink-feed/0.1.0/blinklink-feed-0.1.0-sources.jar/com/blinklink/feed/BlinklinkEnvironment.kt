package com.blinklink.feed

/** Backend environment the SDK talks to. */
enum class BlinklinkEnvironment {
    DEVELOPMENT,
    PRODUCTION,
}
